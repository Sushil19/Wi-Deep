package com.example.wifirssi;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

public class Train_Data extends AppCompatActivity implements CompoundButton.OnCheckedChangeListener{

    static WifiManager wifiManager;
    ConstraintLayout cl_1;
    ScrollView sv;
    static CompoundButton.OnCheckedChangeListener check_ctx;
    static LinearLayout ll;
    static WifiScanReceiver0 wifiReceiver;
    static CheckBox[] dynamicCheckBoxes = new CheckBox[500];
    static ArrayList<String> mac_aps = new ArrayList<String>(500);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        cl_1 = (ConstraintLayout)findViewById(R.id.c1);
        sv = (ScrollView)findViewById(R.id.s1);
        ll = (LinearLayout)findViewById(R.id.l1);
        check_ctx = this;

    }
    public void OnClick(View v){
        ll.removeAllViews();
        Main2Activity.aps = 0;
        Train_Data.mac_aps.clear();
        wifiReceiver = new WifiScanReceiver0();
        getApplicationContext().registerReceiver(wifiReceiver, new
                IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION));
        wifiManager = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        wifiManager.startScan();
    }
    public void OnNext(View v){
        Intent intent = new Intent(this, Main2Activity.class);
        startActivity(intent);
    }


    @Override
    public void onCheckedChanged(CompoundButton compoundButton, boolean b) {

        String arrOfStr = (String) compoundButton.getText();
        String [] str_arr = arrOfStr.split(" ");
        arrOfStr = str_arr[str_arr.length - 1];
        if(b){
            Main2Activity.aps++;
            mac_aps.add(arrOfStr);
            Toast.makeText(this, arrOfStr+" is checked!!!", Toast.LENGTH_SHORT).show();
        } else {
            Main2Activity.aps--;
            mac_aps.remove(arrOfStr);
            Toast.makeText(this, arrOfStr+" is not checked!!!", Toast.LENGTH_SHORT).show();
        }
    }
}
class WifiScanReceiver0 extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent intent) {
        List<ScanResult> scan = Train_Data.wifiManager.getScanResults();
        for (int i = 0; i < scan.size(); i++) {
            //System.out.println(scan.get(i).SSID);
            CheckBox cb = new CheckBox(c);
            cb.setText(scan.get(i).SSID + " " + scan.get(i).BSSID);
            Train_Data.dynamicCheckBoxes[i] = cb;
            cb.setOnCheckedChangeListener(Train_Data.check_ctx);
            Train_Data.ll.addView(cb);
        }
        c.unregisterReceiver(Train_Data.wifiReceiver);
    }
}
