package com.example.wifirssi;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.IntentFilter;
import android.net.wifi.WifiManager;
import android.view.View;



import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;

public class GeneraterWorker extends AsyncTask<String,Void,String> {
    Context context;
    AlertDialog alertDialog;
    ProgressDialog progress;
    static WifiManager wifiManager;
    static String full_Str = "";
    static  String result = "";
    GeneraterWorker (Context ctx) {
        context = ctx;
    }

    @Override
    protected String doInBackground(String... params) {
        WifiScanReceiver3 wifiReceiver = new WifiScanReceiver3();
        while(true) {
            if(Main2Activity.c<=0){
               // context.unregisterReceiver(wifiReceiver);
                break;
            }
            context.registerReceiver(wifiReceiver, new
                    IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION));
            wifiManager = (WifiManager) context.getSystemService(Context.WIFI_SERVICE);
            Main2Activity.count = 0;
            int k = 0;
            Main2Activity.flag = true;
            wifiManager.startScan();
            /*try{
                Thread.sleep(1000);
            }catch(Exception e){

            }*/
            while(Main2Activity.flag);
            String login_url = "http://192.168.0.7/Wideep_Project/post_h.php";
            result = "";
            try {
                URL url = new URL(login_url);
                HttpURLConnection httpURLConnection = (HttpURLConnection)url.openConnection();
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setDoOutput(true);
                httpURLConnection.setDoInput(true);
                OutputStream outputStream = httpURLConnection.getOutputStream();
                BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));
                String post_data = URLEncoder.encode("user_name","UTF-8")+"="+URLEncoder.encode(full_Str,"UTF-8");
                bufferedWriter.write(post_data);
                bufferedWriter.flush();
                bufferedWriter.close();
                outputStream.close();
                InputStream inputStream = httpURLConnection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream,"iso-8859-1"));
                String line="";
                while((line = bufferedReader.readLine())!= null) {
                    result += line;
                }
                System.out.println(result);
                publishProgress();
                //Test_Data.t1.setText(result);
                bufferedReader.close();
                inputStream.close();
                httpURLConnection.disconnect();

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

        }
        return params[0];
    }

    @Override
    protected void onPreExecute() {

    }

    @Override
    protected void onPostExecute(String resulti) {


    }


    @Override
    protected void onProgressUpdate(Void... values) {
        Test_Data.t1.setText(GeneraterWorker.result);
    }
}
class WifiScanReceiver3 extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent intent) {


        if(Main2Activity.c > 0 && intent.getBooleanExtra(WifiManager.EXTRA_RESULTS_UPDATED, false) && Main2Activity.flag){

            Post_Scan obj = new Post_Scan();
            GeneraterWorker.full_Str = obj.test_result(GeneraterWorker.wifiManager);
            Main2Activity.flag = false;
            //System.out.println(full_str);


        }
    }
}
